﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midterm2
{
    public partial class Circle : Form
    {
        public Circle()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            areacalculation circ = new areacalculation();
            double r = Convert.ToInt32(txtR.Text);
            double result = 0;

            result = circ.Circle(r);

                CircleResult res = new CircleResult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }

    }
}
