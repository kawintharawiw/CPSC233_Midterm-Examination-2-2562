﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midterm2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCircle_Click(object sender, EventArgs e)
        {
            Circle frmCircle = new Circle();
            frmCircle.Show();
        }

        private void btnSquare_Click(object sender, EventArgs e)
        {
            Square frmsquare = new Square();
            frmsquare.Show();
        }

        private void btnTriangle_Click(object sender, EventArgs e)
        {
            Triangle frmtriangle = new Triangle();
            frmtriangle.Show();
        }

        private void btnRectangle_Click(object sender, EventArgs e)
        {
            Rectangle frmrectangle = new Rectangle();
            frmrectangle.Show();
        }
    }
}
