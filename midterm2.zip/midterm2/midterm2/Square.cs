﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midterm2
{
    public partial class Square : Form
    {
        public Square()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            areacalculation squ = new areacalculation();
            double D = Convert.ToInt32(txtD.Text);
            double result = 0;

            result = squ.Square(D);

            SquareResult res = new SquareResult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }

    }
}
