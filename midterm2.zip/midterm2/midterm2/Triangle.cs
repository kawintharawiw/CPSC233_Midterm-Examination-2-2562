﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace midterm2
{
    public partial class Triangle : Form
    {
        public Triangle()
        {
            InitializeComponent();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {
            areacalculation rec = new areacalculation();
            double width = Convert.ToDouble(txtW.Text);
            double height = Convert.ToDouble(txtH.Text);
            double result = 0;

            result = rec.Triangle(width, height);

            TriangleResult res = new TriangleResult();
            res.Show();
            res.txtResult.Text = Convert.ToString(result);
        }
    }
}
