﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace midterm2
{
    class areacalculation
    {
        double Cirleresult, Squareresult, Rectangleresult, Triangleresult;

        public double Circle(double R)
        {
            Cirleresult = 3.14 * (R * R);
            return Cirleresult;
        }

        public double Square(double D)
        {
            Squareresult = D * D;
            return Squareresult;
        }

        public double Triangle(double Height, double Width)
        {
            Triangleresult = 0.5 * (Height * Width);
            return Triangleresult;
        }        public double Rectangle(double Width, double Long)
        {
            Rectangleresult = Width * Long;
            return Rectangleresult;
        }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}
